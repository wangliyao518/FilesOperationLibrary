ute_common_store
================

Library to manage objects (add/remove/get). Store object is protecting created aliases and provides user-friendly
feadback for the user in case of error.

Requirements
============

* Python 2.7.x
* setuptools >=2.1
* pip >= 1.5

UTE installation
================

pip install svn+https://ca_ute_test:utetest@svne1.access.nsn.com/isource/svnroot/utelibs/ute_common_store/trunk/#egg=ute_common_store

Non UTE installation
====================

| pip install -U -i http://wrling37.emea.nsn-net.net:25101/ute_files/pypi/packages/ pip
| pip install -U -i http://wrling37.emea.nsn-net.net:25101/ute_files/pypi/packages/ setuptools
| pip install -U -i http://wrling37.emea.nsn-net.net:25101/ute_files/pypi/packages/ ute_installer
| pip install svn+https://ca_ute_test:utetest@svne1.access.nsn.com/isource/svnroot/utelibs/ute_common_store/trunk/#egg=ute_common_store

