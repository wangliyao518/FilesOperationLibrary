# -*- coding: utf-8 -*-
"""
:copyright: NSN
:author: Bartlomiej Idzikowski
:contact: bartlomiej.idzikowski@nsn.com
"""

from ute_installer.setup import setup

setup(
    name='ute_common_store',
    version='1.3.0',
    description='UTE common store library used to manage objects (add/remove/show/protect).',
    author='Pawel Chomicki',
    author_email='pawel.chomicki@nsn.com'
)
