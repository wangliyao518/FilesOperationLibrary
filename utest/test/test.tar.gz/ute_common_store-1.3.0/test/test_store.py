# -*- coding: utf-8 -*-
"""
:author: Pawel Chomicki
:contact: pawel.chomicki@nsn.com
"""
import unittest

from mock import Mock
from ute_common_store import Store
from ute_common_store.exception import NameIsProtected, AliasError


class TestStore(unittest.TestCase):
    def setUp(self):
        self.store = Store()

    def test__add__adds_new_value(self):
        self.store.add(value="value")
        self.assertEqual(self.store.aliases, ["default"])

    def test__add__adds_new_value_with_alias(self):
        self.store.add(value="value", alias="name")
        self.assertEqual(self.store.aliases, ["name"])

    def test__add__raises_error_when_value_is_not_specified(self):
        with self.assertRaises(TypeError):
            self.store.add()

    def test__add__raises_error_if_alias_exists(self):
        self.store.add(value="value")
        with self.assertRaises(NameIsProtected):
            self.store.add(value="value")

    def test__remove__removes_value(self):
        self.store.add(value="value")
        self.store.remove()
        self.assertEqual(self.store.aliases, [])

    def test__remove__raise_error_if_store_is_empty(self):
        with self.assertRaises(AliasError):
            self.store.remove()

    def test__get__without_args_returns_default_object(self):
        self.store.add(value="value")
        self.assertEqual(self.store.get(), "value")

    def test__get__raises_error_if_store_is_empty(self):
        with self.assertRaises(AliasError):
            self.store.get()

    def test__get__returns_value_for_specified_alias(self):
        self.store.add(value="value", alias="name")
        self.assertEqual(self.store.get(alias="name"), "value")

    def test__aliases__returns_list_of_available_aliases(self):
        self.store.add(value="value", alias="name")
        self.store.add(value="value", alias="name2")
        aliases = self.store.aliases
        self.assertIn("name", aliases)
        self.assertIn("name2", aliases)

    def test__is_alias_exists__returns_true_if_alias_was_added(self):
        self.store.add(value="value")
        self.store.add(value="value", alias="alias2")
        self.assertTrue(self.store.has_alias())
        self.assertTrue(self.store.has_alias("alias2"))

    def test__is_alias_exists__returns_false_if_alias_does_not_exist(self):
        self.store.add(value="value", alias="alias3")
        self.assertFalse(self.store.has_alias())
        self.assertFalse(self.store.has_alias("alias4"))

    def test__iter__iterates_over_elements(self):
        test1 = Mock()
        test2 = Mock()
        self.store.add(value=test1)
        self.store.add(value=test2, alias="alias2")
        for each in self.store:
            each()
        test1.assert_any_call()
        test2.assert_any_call()

if __name__ == "__main__":
    unittest.main()
